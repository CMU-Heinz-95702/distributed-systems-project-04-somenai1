/**
 * MainActivity.java
 * Author: Serena Omenai
 * Email: somenai@andrew.cmu.edu
 * Andrew id: somenai
 */

package com.example.catsearch;

//import the necessary packages
import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    // UI components
    EditText breedInput;
    Button searchBtn;
    ImageView catImage;
    TextView catInfo, wikiLink;
    ProgressBar progressBar;

    // Holds the Wikipedia URL of the cat breed
    String wikipediaUrl = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Apply window insets (e.g., padding for status/navigation bars)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize views
        breedInput = findViewById(R.id.breedInput);
        searchBtn = findViewById(R.id.searchBtn);
        catImage = findViewById(R.id.catImage);
        catInfo = findViewById(R.id.catInfo);
        wikiLink = findViewById(R.id.wikiLink);
        progressBar = findViewById(R.id.progressBar);

        // Open Wikipedia link in browser when clicked
        wikiLink.setOnClickListener(v -> {
            if (wikipediaUrl != null) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(wikipediaUrl));
                startActivity(browserIntent);
            }
        });

        // Handle search button click
        searchBtn.setOnClickListener(view -> {
            String breed = breedInput.getText().toString().trim();
            if (!breed.isEmpty()) {
                fetchCatData(breed); // Trigger the API call
            }
        });
    }

    // Sends HTTP request to the web service to fetch cat data
    private void fetchCatData(String breed) {
        String apiUrl = "https://ominous-space-fishstick-r46x54prx965cpg7-8080.app.github.dev/catsearch?breed=" + breed;

        // Reset UI state before fetching
        progressBar.setVisibility(View.VISIBLE);
        wikiLink.setVisibility(View.GONE);
        catInfo.setText("");
        catImage.setImageDrawable(null);

        // Perform network operation on a background thread
        new Thread(() -> {
            try {
                URL url = new URL(apiUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("Accept", "application/json");

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) result.append(line);
                reader.close();

                JSONObject json = new JSONObject(result.toString());

                // Switch to UI thread to update views
                runOnUiThread(() -> updateUI(json));

            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(MainActivity.this, "Error fetching data", Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    // Updates the UI based on the JSON response from the API
    @SuppressLint("SetTextI18n")
    private void updateUI(JSONObject json) {
        try {
            progressBar.setVisibility(View.GONE);

            String status = json.getString("status");

            if (status.equals("success") && json.has("breed")) {
                JSONObject breed = json.getJSONObject("breed");

                // Extract breed details
                String imageUrl = breed.getJSONObject("image").getString("url");
                String name = breed.optString("name", "Unknown");
                String origin = breed.optString("origin", "Unknown");
                String lifeSpan = breed.optString("life_span", "N/A");
                String temperament = breed.optString("temperament", "N/A");
                String description = breed.optString("description", "No description available");

                // Handle Wikipedia link visibility
                wikipediaUrl = breed.optString("wikipedia_url", null);
                if (wikipediaUrl != null && !wikipediaUrl.isEmpty()) {
                    wikiLink.setVisibility(View.VISIBLE);
                } else {
                    wikiLink.setVisibility(View.GONE);
                }

                // Construct info text for display
                String infoText = "Name: " + name +
                        "\nOrigin: " + origin +
                        "\nLifespan: " + lifeSpan + " years" +
                        "\n\nTemperament: " + temperament +
                        "\n\nDescription:\n" + description;

                // Display image and details
                Picasso.get().load(imageUrl).into(catImage);
                catInfo.setText(infoText);
            } else {
                // Breed not found case
                catInfo.setText("Breed not found.");
                catImage.setImageDrawable(null);
                wikiLink.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            // Handle any errors during JSON parsing
            progressBar.setVisibility(View.GONE);
            catInfo.setText("Failed to parse response.");
            e.printStackTrace();
        }
    }
}
