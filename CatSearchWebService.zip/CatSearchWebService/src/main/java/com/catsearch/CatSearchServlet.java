/**
 * CatSearchServlet.java
 * Author: Serena Omenai
 * Email: somenai@andrew.cmu.edu
 * Andrew id: somenai
 */

package com.catsearch;

//import necessary libraries
import org.json.JSONArray;
import org.json.JSONObject;
import com.mongodb.client.*;
import org.bson.Document;

import jakarta.servlet.http.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.Date;

public class CatSearchServlet extends HttpServlet {
    // Base URL for The Cat API
    private static final String API_URL = "https://api.thecatapi.com/v1/";
    // API key for authenticating requests to The Cat API
    private static final String API_KEY = "live_9sW420WIjT4GdVXdmL8RnkiYoGQ2iB8hgtKjFUhGOtDveyzOfBWvDQ365Flo9gpH";

    // MongoDB client and collection for logging search interactions
    private MongoClient mongoClient;
    private MongoCollection<Document> logCollection;

    @Override
    public void init() {
        // Initialize MongoDB connection
        String uri = "mongodb+srv://catuser:catpass123@catsearchcluster.jdyq1yg.mongodb.net/?retryWrites=true&w=majority&appName=Catsearchcluster";
        mongoClient = MongoClients.create(uri);
        MongoDatabase db = mongoClient.getDatabase("catAppDB");
        logCollection = db.getCollection("searchLogs");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        String breedQuery = request.getParameter("breed");
        JSONObject jsonResponse = new JSONObject();
        long startTime = System.currentTimeMillis(); // Track latency

        try {
            if (breedQuery == null || breedQuery.isEmpty()) {
                // Return a random cat if no breed specified
                JSONObject randomCat = fetchRandomCat();
                jsonResponse.put("status", "success");
                jsonResponse.put("breed", randomCat);
            } else {
                JSONArray allBreeds = fetchAllBreeds();
                JSONObject matched = findBreedByName(allBreeds, breedQuery);

                if (matched != null) {
                    jsonResponse.put("status", "success");
                    jsonResponse.put("breed", matched);
                } else {
                    jsonResponse.put("status", "error");
                    jsonResponse.put("message", "Breed not found");
                }
            }
        } catch (Exception e) {
            jsonResponse.put("status", "error");
            jsonResponse.put("message", "Internal server error");
            e.printStackTrace();
        }

        logInteraction(request, breedQuery, jsonResponse, System.currentTimeMillis() - startTime);
        response.setContentType("application/json");
        response.getWriter().print(jsonResponse);
    }

    // Fetch all cat breeds from The Cat API
    private JSONArray fetchAllBreeds() throws IOException {
        return new JSONArray(httpGet(API_URL + "breeds"));
    }

    // Fetch a random cat image and wrap it in a breed-style object
    private JSONObject fetchRandomCat() throws IOException {
        JSONArray arr = new JSONArray(httpGet(API_URL + "images/search"));
        JSONObject image = arr.getJSONObject(0);

        JSONObject wrapper = new JSONObject();
        wrapper.put("name", "Random Cat");
        wrapper.put("description", "Here's a random cat!");
        wrapper.put("origin", "Unknown");
        wrapper.put("image", image);
        return wrapper;
    }

    // Find a breed by name (case-insensitive match and fallback to partial)
    private JSONObject findBreedByName(JSONArray breeds, String query) {
        for (int i = 0; i < breeds.length(); i++) {
            JSONObject breed = breeds.getJSONObject(i);
            if (breed.getString("name").equalsIgnoreCase(query)) {
                return breed;
            }
        }

        for (int i = 0; i < breeds.length(); i++) {
            JSONObject breed = breeds.getJSONObject(i);
            if (breed.getString("name").toLowerCase().contains(query.toLowerCase())) {
                return breed;
            }
        }

        return null;
    }

    // Perform HTTP GET request to given URL with API key
    private String httpGet(String urlStr) throws IOException {
        try {
            URI uri = URI.create(urlStr);
            URL url = uri.toURL();
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("x-api-key", API_KEY);

            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder result = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) result.append(line);
            reader.close();

            return result.toString();
        } catch (Exception e) {
            throw new IOException("Failed to fetch data from URL: " + urlStr, e);
        }
    }

    // Log API request/response details to MongoDB
    private void logInteraction(HttpServletRequest request, String breedQuery, JSONObject responseJson, long latencyMs) {
        Document log = new Document()
                .append("timestamp", new Date())
                .append("clientIP", request.getRemoteAddr())
                .append("userAgent", request.getHeader("User-Agent"))
                .append("searchTerm", breedQuery)
                .append("latencyMs", latencyMs)
                .append("responseSnippet", responseJson.toString().substring(0, Math.min(200, responseJson.toString().length())));
        logCollection.insertOne(log);
    }

    @Override
    public void destroy() {
        mongoClient.close();
    }
}