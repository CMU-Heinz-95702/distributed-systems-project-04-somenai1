/**
 * DashboardServlet.java
 * Author: Serena Omenai
 * Email: somenai@andrew.cmu.edu
 * Andrew id: somenai
 */

package com.catsearch;

import com.mongodb.client.*;
import org.bson.Document;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class DashboardServlet extends HttpServlet {
    private MongoCollection<Document> logCollection;

    // Initialize MongoDB connection and log collection
    @Override
    public void init() {
        String uri = "mongodb+srv://catuser:catpass123@catsearchcluster.jdyq1yg.mongodb.net/?retryWrites=true&w=majority&appName=Catsearchcluster";
        MongoClient mongoClient = MongoClients.create(uri);
        MongoDatabase db = mongoClient.getDatabase("catAppDB");
        logCollection = db.getCollection("searchLogs");
    }

    // Handle GET request to serve dashboard data
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Set response encoding to UTF-8 to avoid symbol issues
        response.setContentType("text/html;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");

        // Get all logs sorted by latest first
        List<Document> logs = logCollection.find().sort(new Document("timestamp", -1)).into(new ArrayList<>());

        // Analytics 1: Top 5 most searched cat breeds
        Map<String, Long> breedCounts = logs.stream()
                .filter(doc -> doc.containsKey("searchTerm") && doc.getString("searchTerm") != null)
                .collect(Collectors.groupingBy(doc -> doc.getString("searchTerm"), Collectors.counting()));

        List<Map.Entry<String, Long>> topBreeds = breedCounts.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .limit(5)
                .collect(Collectors.toList());

        // Analytics 2: Average latency of requests
        double avgLatency = logs.stream()
                .filter(doc -> doc.containsKey("latencyMs"))
                .mapToLong(doc -> doc.getLong("latencyMs"))
                .average()
                .orElse(0.0);

        // Analytics 3: Most common user agent (browser/device making requests)
        Map<String, Long> agentCounts = logs.stream()
                .filter(doc -> doc.containsKey("userAgent"))
                .collect(Collectors.groupingBy(doc -> doc.getString("userAgent"), Collectors.counting()));

        String topAgent = agentCounts.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("Unknown");

        // Pass results to dashboard.jsp
        request.setAttribute("logs", logs);
        request.setAttribute("topBreeds", topBreeds);
        request.setAttribute("avgLatency", avgLatency);
        request.setAttribute("topAgent", topAgent);

        // Forward request to JSP for rendering
        request.getRequestDispatcher("/dashboard.jsp").forward(request, response);
    }
}